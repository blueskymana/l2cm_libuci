/*************************************************************************
	> File Name: l2_uci.h
	> Author: 
	> Mail: 
	> Created Time: 2017年04月18日 星期二 16时50分44秒
 ************************************************************************/

#ifndef _L2_UCI_H
#define _L2_UCI_H

int Uci_get(char *in, char *out);
int L2_uci_set(char *in);
int L2_uci_set_for(char *in);
int read_cmd(char *in, char *out);

#endif

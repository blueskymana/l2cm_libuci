/*************************************************************************
	> File Name: l2_log.h
	> Author: 
	> Mail: 
	> Created Time: 2017年04月18日 星期二 17时01分41秒
 ************************************************************************/

#ifndef _L2_LOG_H
#define _L2_LOG_H
#define DEBUG 1
#define u_char unsigned char
void print_payload(const u_char *payload, int len);
#endif
